import styles from "./ProductHeader.module.css";
function ProductHeader() {
  return (
    <div className={styles.container}>
      <p className={styles.title}>SEE OUR PRODUCTS</p>
    </div>
  );
}

export default ProductHeader;
